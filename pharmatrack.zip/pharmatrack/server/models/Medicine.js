const mongoose = require('mongoose');

const CATEGORIES = [
  'Analgesic', 'Antibiotic', 'Antihistamine', 'Antacid', 'Antidiabetic',
  'Antihypertensive', 'Lipid Lowering', 'Antiasthmatic', 'NSAID', 'Vitamin',
  'ORS', 'Proton Pump Inhibitor', 'Antifungal', 'Antiviral', 'Steroid',
  'Cardiac', 'Neurological', 'Dermatological', 'Ophthalmic', 'ENT', 'Other'
];

const medicineSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Medicine name is required'],
    trim: true
  },
  genericName: {
    type: String,
    required: [true, 'Generic name is required'],
    trim: true
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: CATEGORIES
  },
  manufacturer: {
    type: String,
    required: [true, 'Manufacturer is required'],
    trim: true
  },
  unit: {
    type: String,
    required: [true, 'Unit is required'],
    enum: ['Tablets', 'Capsules', 'Syrup (ml)', 'Injection (ml)', 'Cream (g)', 'Ointment (g)', 'Drops (ml)', 'Sachet', 'Inhaler', 'Patch', 'Suppository', 'Powder (g)', 'Strips'],
    default: 'Tablets'
  },
  minimumStock: {
    type: Number,
    required: [true, 'Minimum stock level is required'],
    min: [0, 'Minimum stock cannot be negative'],
    default: 10
  },
  storageLocation: {
    type: String,
    trim: true,
    default: 'General Storage'
  },
  description: {
    type: String
  },
  notes: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  // Virtual total quantity computed from batches
  totalQuantity: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual populate batches
medicineSchema.virtual('batches', {
  ref: 'Batch',
  localField: '_id',
  foreignField: 'medicine'
});

module.exports = mongoose.model('Medicine', medicineSchema);
module.exports.CATEGORIES = CATEGORIES;
