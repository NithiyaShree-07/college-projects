/**
 * Utility: Calculate expiry status from an expiry date
 * Always computed fresh from current date — never stored in DB
 */
const getExpiryStatus = (expiryDate) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  const diffMs = expiry - today;
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return { status: 'EXPIRED', daysUntilExpiry: diffDays };
  if (diffDays <= 7) return { status: 'EXPIRING_SOON', daysUntilExpiry: diffDays };
  if (diffDays <= 30) return { status: 'EXPIRING', daysUntilExpiry: diffDays };
  return { status: 'SAFE', daysUntilExpiry: diffDays };
};

/**
 * Get stock status based on quantity vs minimum stock
 */
const getStockStatus = (quantity, minimumStock) => {
  if (quantity === 0) return 'OUT_OF_STOCK';
  if (quantity <= minimumStock) return 'LOW_STOCK';
  return 'IN_STOCK';
};

module.exports = { getExpiryStatus, getStockStatus };
