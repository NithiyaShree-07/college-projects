/**
 * PharmaTrack Seed Script
 * DISCLAIMER: This is DEMO INVENTORY DATA for educational/testing purposes only.
 * This does NOT represent an actual pharmacy. No medical advice is provided.
 * Run: npm run seed
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const Admin = require('../models/Admin');
const Supplier = require('../models/Supplier');
const Medicine = require('../models/Medicine');
const Batch = require('../models/Batch');
const StockTransaction = require('../models/StockTransaction');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/pharmatrack';

// Helper to get date relative to today
const daysFromNow = (days) => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + days);
  return d;
};

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Admin.deleteMany({});
    await Supplier.deleteMany({});
    await Medicine.deleteMany({});
    await Batch.deleteMany({});
    await StockTransaction.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // ============ CREATE ADMIN ============
    const adminData = {
      name: 'Dr. Pharmacy Admin',
      email: 'admin@pharmatrack.com',
      password: 'Admin@123',
      role: 'admin'
    };
    const admin = await Admin.create(adminData);
    console.log(`👤 Admin created: ${admin.email}`);

    // ============ CREATE SUPPLIERS ============
    const suppliersData = [
      { name: 'MedLife Pharmaceuticals', contactPerson: 'Rajesh Kumar', phone: '+91-9876543210', email: 'rajesh@medlife.com', address: 'Chennai, Tamil Nadu', gstin: 'GSTIN33AAA1234' },
      { name: 'HealthFirst Distributors', contactPerson: 'Priya Sharma', phone: '+91-9823456789', email: 'priya@healthfirst.com', address: 'Mumbai, Maharashtra', gstin: 'GSTIN27BBB5678' },
      { name: 'PharmaCare Supplies', contactPerson: 'Amit Patel', phone: '+91-9745678901', email: 'amit@pharmacare.com', address: 'Ahmedabad, Gujarat', gstin: 'GSTIN24CCC9012' },
      { name: 'GlobalMed Traders', contactPerson: 'Sunita Verma', phone: '+91-9634567890', email: 'sunita@globalmed.com', address: 'Delhi, NCR', gstin: 'GSTIN07DDD3456' },
      { name: 'CurePoint Pharma', contactPerson: 'Vikram Singh', phone: '+91-9512345678', email: 'vikram@curepoint.com', address: 'Bangalore, Karnataka', gstin: 'GSTIN29EEE7890' }
    ];

    const suppliers = await Supplier.insertMany(suppliersData);
    console.log(`🏪 ${suppliers.length} suppliers created`);

    const [s1, s2, s3, s4, s5] = suppliers;

    // ============ CREATE MEDICINES + BATCHES ============
    // DISCLAIMER: For educational demonstration only. No medical advice.

    const medicinesData = [
      {
        name: 'Crocin Advance', genericName: 'Paracetamol 500mg', category: 'Analgesic',
        manufacturer: 'GlaxoSmithKline', unit: 'Tablets', minimumStock: 50, storageLocation: 'Rack A1',
        notes: 'Store below 30°C. Demo data only.',
        batches: [
          { supplier: s1._id, batchNumber: 'PCM-A101', quantity: 250, purchasePrice: 2.5, sellingPrice: 3.5, mfgDays: -365, expDays: 365 },
          { supplier: s1._id, batchNumber: 'PCM-A102', quantity: 15, purchasePrice: 2.5, sellingPrice: 3.5, mfgDays: -180, expDays: 5 },
          { supplier: s2._id, batchNumber: 'PCM-A103', quantity: 80, purchasePrice: 2.6, sellingPrice: 3.6, mfgDays: -90, expDays: 200 }
        ]
      },
      {
        name: 'Cetzine', genericName: 'Cetirizine 10mg', category: 'Antihistamine',
        manufacturer: 'Dr. Reddys Laboratories', unit: 'Tablets', minimumStock: 30, storageLocation: 'Rack A2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s2._id, batchNumber: 'CTZ-B201', quantity: 0, purchasePrice: 3.0, sellingPrice: 4.5, mfgDays: -400, expDays: -30 },
          { supplier: s2._id, batchNumber: 'CTZ-B202', quantity: 8, purchasePrice: 3.0, sellingPrice: 4.5, mfgDays: -200, expDays: 3 }
        ]
      },
      {
        name: 'Azithral 500', genericName: 'Azithromycin 500mg', category: 'Antibiotic',
        manufacturer: 'Alembic Pharmaceuticals', unit: 'Tablets', minimumStock: 20, storageLocation: 'Rack B1',
        notes: 'Demo data only.',
        batches: [
          { supplier: s3._id, batchNumber: 'AZT-C301', quantity: 60, purchasePrice: 18.0, sellingPrice: 25.0, mfgDays: -60, expDays: 540 },
          { supplier: s3._id, batchNumber: 'AZT-C302', quantity: 10, purchasePrice: 18.5, sellingPrice: 25.5, mfgDays: -30, expDays: 20 }
        ]
      },
      {
        name: 'Novamox 500', genericName: 'Amoxicillin 500mg', category: 'Antibiotic',
        manufacturer: 'Cipla Ltd', unit: 'Capsules', minimumStock: 25, storageLocation: 'Rack B2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s1._id, batchNumber: 'AMX-D401', quantity: 120, purchasePrice: 10.0, sellingPrice: 14.0, mfgDays: -90, expDays: 300 },
          { supplier: s4._id, batchNumber: 'AMX-D402', quantity: 0, purchasePrice: 10.5, sellingPrice: 14.5, mfgDays: -500, expDays: -60 }
        ]
      },
      {
        name: 'Brufen 400', genericName: 'Ibuprofen 400mg', category: 'NSAID',
        manufacturer: 'Abbott India', unit: 'Tablets', minimumStock: 40, storageLocation: 'Rack A3',
        notes: 'Demo data only.',
        batches: [
          { supplier: s4._id, batchNumber: 'IBU-E501', quantity: 200, purchasePrice: 4.0, sellingPrice: 6.0, mfgDays: -120, expDays: 600 },
          { supplier: s4._id, batchNumber: 'IBU-E502', quantity: 12, purchasePrice: 4.0, sellingPrice: 6.0, mfgDays: -180, expDays: 25 }
        ]
      },
      {
        name: 'Pan 40', genericName: 'Pantoprazole 40mg', category: 'Proton Pump Inhibitor',
        manufacturer: 'Alkem Laboratories', unit: 'Tablets', minimumStock: 30, storageLocation: 'Rack C1',
        notes: 'Demo data only.',
        batches: [
          { supplier: s5._id, batchNumber: 'PAN-F601', quantity: 150, purchasePrice: 8.0, sellingPrice: 12.0, mfgDays: -45, expDays: 400 },
          { supplier: s5._id, batchNumber: 'PAN-F602', quantity: 5, purchasePrice: 8.0, sellingPrice: 12.0, mfgDays: -300, expDays: 6 }
        ]
      },
      {
        name: 'Omez 20', genericName: 'Omeprazole 20mg', category: 'Proton Pump Inhibitor',
        manufacturer: 'Dr. Reddys Laboratories', unit: 'Capsules', minimumStock: 25, storageLocation: 'Rack C2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s2._id, batchNumber: 'OMZ-G701', quantity: 90, purchasePrice: 6.0, sellingPrice: 9.0, mfgDays: -100, expDays: 450 }
        ]
      },
      {
        name: 'Glycomet 500', genericName: 'Metformin 500mg', category: 'Antidiabetic',
        manufacturer: 'USV Limited', unit: 'Tablets', minimumStock: 50, storageLocation: 'Rack D1',
        notes: 'Demo data only.',
        batches: [
          { supplier: s3._id, batchNumber: 'MET-H801', quantity: 300, purchasePrice: 3.5, sellingPrice: 5.0, mfgDays: -60, expDays: 700 },
          { supplier: s3._id, batchNumber: 'MET-H802', quantity: 20, purchasePrice: 3.5, sellingPrice: 5.0, mfgDays: -400, expDays: 2 }
        ]
      },
      {
        name: 'Amlip 5', genericName: 'Amlodipine 5mg', category: 'Antihypertensive',
        manufacturer: 'Cipla Ltd', unit: 'Tablets', minimumStock: 40, storageLocation: 'Rack D2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s1._id, batchNumber: 'AML-I901', quantity: 180, purchasePrice: 5.0, sellingPrice: 7.5, mfgDays: -90, expDays: 500 },
          { supplier: s5._id, batchNumber: 'AML-I902', quantity: 0, purchasePrice: 5.0, sellingPrice: 7.5, mfgDays: -600, expDays: -90 }
        ]
      },
      {
        name: 'Losartan 50', genericName: 'Losartan Potassium 50mg', category: 'Antihypertensive',
        manufacturer: 'Sun Pharmaceutical', unit: 'Tablets', minimumStock: 35, storageLocation: 'Rack D3',
        notes: 'Demo data only.',
        batches: [
          { supplier: s4._id, batchNumber: 'LOS-J001', quantity: 160, purchasePrice: 7.0, sellingPrice: 10.0, mfgDays: -75, expDays: 600 }
        ]
      },
      {
        name: 'Atorva 10', genericName: 'Atorvastatin 10mg', category: 'Lipid Lowering',
        manufacturer: 'Torrent Pharmaceuticals', unit: 'Tablets', minimumStock: 30, storageLocation: 'Rack E1',
        notes: 'Demo data only.',
        batches: [
          { supplier: s2._id, batchNumber: 'ATV-K101', quantity: 140, purchasePrice: 6.5, sellingPrice: 9.5, mfgDays: -50, expDays: 750 },
          { supplier: s2._id, batchNumber: 'ATV-K102', quantity: 7, purchasePrice: 6.5, sellingPrice: 9.5, mfgDays: -250, expDays: 28 }
        ]
      },
      {
        name: 'Montair 10', genericName: 'Montelukast 10mg', category: 'Antiasthmatic',
        manufacturer: 'Cipla Ltd', unit: 'Tablets', minimumStock: 25, storageLocation: 'Rack E2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s5._id, batchNumber: 'MON-L201', quantity: 100, purchasePrice: 9.0, sellingPrice: 13.0, mfgDays: -110, expDays: 480 }
        ]
      },
      {
        name: 'Voveran SR', genericName: 'Diclofenac Sodium 100mg', category: 'NSAID',
        manufacturer: 'Novartis India', unit: 'Tablets', minimumStock: 20, storageLocation: 'Rack A4',
        notes: 'Demo data only.',
        batches: [
          { supplier: s1._id, batchNumber: 'DIC-M301', quantity: 75, purchasePrice: 5.5, sellingPrice: 8.0, mfgDays: -80, expDays: 380 },
          { supplier: s1._id, batchNumber: 'DIC-M302', quantity: 0, purchasePrice: 5.5, sellingPrice: 8.0, mfgDays: -550, expDays: -120 }
        ]
      },
      {
        name: 'Electral ORS', genericName: 'Oral Rehydration Salts', category: 'ORS',
        manufacturer: 'Franco-Indian Pharmaceuticals', unit: 'Sachet', minimumStock: 50, storageLocation: 'Rack F1',
        notes: 'Demo data only.',
        batches: [
          { supplier: s3._id, batchNumber: 'ORS-N401', quantity: 400, purchasePrice: 1.5, sellingPrice: 2.5, mfgDays: -30, expDays: 900 },
          { supplier: s3._id, batchNumber: 'ORS-N402', quantity: 6, purchasePrice: 1.5, sellingPrice: 2.5, mfgDays: -200, expDays: 15 }
        ]
      },
      {
        name: 'Beplex Forte', genericName: 'Vitamin B Complex', category: 'Vitamin',
        manufacturer: 'Anglo French Drugs', unit: 'Tablets', minimumStock: 30, storageLocation: 'Rack F2',
        notes: 'Demo data only.',
        batches: [
          { supplier: s4._id, batchNumber: 'VBC-O501', quantity: 200, purchasePrice: 4.0, sellingPrice: 6.0, mfgDays: -45, expDays: 720 },
          { supplier: s5._id, batchNumber: 'VBC-O502', quantity: 9, purchasePrice: 4.0, sellingPrice: 6.0, mfgDays: -300, expDays: 1 }
        ]
      }
    ];

    let totalBatches = 0;
    const createdMedicines = [];

    for (const medData of medicinesData) {
      const { batches: batchData, ...medFields } = medData;

      const medicine = await Medicine.create(medFields);
      createdMedicines.push(medicine);

      let totalQty = 0;

      for (const bd of batchData) {
        const batch = await Batch.create({
          medicine: medicine._id,
          supplier: bd.supplier,
          batchNumber: bd.batchNumber,
          quantity: bd.quantity,
          purchasePrice: bd.purchasePrice,
          sellingPrice: bd.sellingPrice,
          manufacturingDate: daysFromNow(bd.mfgDays),
          expiryDate: daysFromNow(bd.expDays)
        });

        if (bd.quantity > 0) {
          await StockTransaction.create({
            medicine: medicine._id,
            batch: batch._id,
            admin: admin._id,
            transactionType: 'INITIAL',
            quantity: bd.quantity,
            previousQuantity: 0,
            newQuantity: bd.quantity,
            reason: 'Seed: initial stock'
          });
        }

        totalQty += bd.quantity;
        totalBatches++;
      }

      await Medicine.findByIdAndUpdate(medicine._id, { totalQuantity: totalQty });
    }

    console.log(`💊 ${createdMedicines.length} medicines created`);
    console.log(`📦 ${totalBatches} batches created`);

    console.log('\n✅ ===== SEED COMPLETE =====');
    console.log('📋 Demo admin login:');
    console.log('   Email:    admin@pharmatrack.com');
    console.log('   Password: Admin@123');
    console.log('\n⚠️  DISCLAIMER: This is DEMO INVENTORY DATA for educational/testing purposes only.');
    console.log('    This does NOT represent an actual pharmacy. No medical advice is provided.\n');

    await mongoose.disconnect();
    process.exit(0);
  } catch (error) {
    console.error('❌ Seed error:', error);
    await mongoose.disconnect();
    process.exit(1);
  }
}

seed();
