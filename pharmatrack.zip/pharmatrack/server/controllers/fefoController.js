const Batch = require('../models/Batch');
const Medicine = require('../models/Medicine');
const { getExpiryStatus } = require('../utils/expiryHelper');

// @desc  Get FEFO recommendations
// @route GET /api/fefo
// @access Private
const getFEFO = async (req, res) => {
  try {
    const medicines = await Medicine.find({ isActive: true }).sort({ name: 1 });

    const fefoData = await Promise.all(medicines.map(async (med) => {
      const batches = await Batch.find({ medicine: med._id, isActive: true, quantity: { $gt: 0 } })
        .populate('supplier', 'name')
        .sort({ expiryDate: 1 }); // FEFO: sort by nearest expiry first

      if (batches.length < 1) return null;

      const enrichedBatches = batches.map((b, idx) => ({
        ...b.toObject(),
        ...getExpiryStatus(b.expiryDate),
        fefoRank: idx + 1,
        recommendation: idx === 0 ? 'USE FIRST' : idx === 1 ? 'USE NEXT' : 'USE LATER'
      }));

      return {
        medicine: { _id: med._id, name: med.name, genericName: med.genericName, category: med.category, unit: med.unit },
        batchCount: batches.length,
        batches: enrichedBatches,
        totalQuantity: batches.reduce((sum, b) => sum + b.quantity, 0)
      };
    }));

    const result = fefoData.filter(Boolean).filter(f => f.batchCount > 0);

    res.status(200).json({ success: true, data: result });
  } catch (error) {
    console.error('FEFO error:', error);
    res.status(500).json({ success: false, message: 'Error fetching FEFO data' });
  }
};

module.exports = { getFEFO };
