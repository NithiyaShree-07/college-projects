const Batch = require('../models/Batch');
const Medicine = require('../models/Medicine');
const StockTransaction = require('../models/StockTransaction');
const { getExpiryStatus, getStockStatus } = require('../utils/expiryHelper');
const { updateMedicineTotalQty } = require('./medicineController');

// @desc  Get all batches
// @route GET /api/batches
// @access Private
const getBatches = async (req, res) => {
  try {
    const { medicineId, page = 1, limit = 20 } = req.query;
    const query = { isActive: true };
    if (medicineId) query.medicine = medicineId;

    const batches = await Batch.find(query)
      .populate('medicine', 'name genericName category unit minimumStock')
      .populate('supplier', 'name phone email')
      .sort({ expiryDate: 1 });

    const enriched = batches.map(b => ({
      ...b.toObject(),
      ...getExpiryStatus(b.expiryDate),
      stockStatus: getStockStatus(b.quantity, b.medicine?.minimumStock || 10)
    }));

    res.status(200).json({ success: true, data: enriched, total: enriched.length });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching batches' });
  }
};

// @desc  Create new batch for existing medicine
// @route POST /api/batches
// @access Private
const createBatch = async (req, res) => {
  try {
    const { medicine, supplier, batchNumber, quantity, purchasePrice, sellingPrice, manufacturingDate, expiryDate } = req.body;

    if (new Date(expiryDate) <= new Date(manufacturingDate)) {
      return res.status(400).json({ success: false, message: 'Expiry date must be after manufacturing date' });
    }

    const med = await Medicine.findById(medicine);
    if (!med) return res.status(404).json({ success: false, message: 'Medicine not found' });

    // Check duplicate batch number for same medicine
    const existing = await Batch.findOne({ medicine, batchNumber });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Batch number already exists for this medicine' });
    }

    const batch = await Batch.create({
      medicine, supplier, batchNumber,
      quantity: parseInt(quantity),
      purchasePrice: parseFloat(purchasePrice),
      sellingPrice: parseFloat(sellingPrice),
      manufacturingDate, expiryDate
    });

    if (parseInt(quantity) > 0) {
      await StockTransaction.create({
        medicine,
        batch: batch._id,
        admin: req.admin._id,
        transactionType: 'STOCK_ADDED',
        quantity: parseInt(quantity),
        previousQuantity: 0,
        newQuantity: parseInt(quantity),
        reason: 'New batch added'
      });
    }

    await updateMedicineTotalQty(medicine);

    const populated = await Batch.findById(batch._id)
      .populate('medicine', 'name')
      .populate('supplier', 'name');

    res.status(201).json({ success: true, message: 'Batch created successfully', data: populated });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Batch number already exists for this medicine' });
    }
    res.status(500).json({ success: false, message: error.message || 'Error creating batch' });
  }
};

// @desc  Update batch
// @route PUT /api/batches/:id
// @access Private
const updateBatch = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.id);
    if (!batch) return res.status(404).json({ success: false, message: 'Batch not found' });

    const updated = await Batch.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('medicine', 'name').populate('supplier', 'name');

    await updateMedicineTotalQty(updated.medicine._id || updated.medicine);

    res.status(200).json({ success: true, message: 'Batch updated', data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating batch' });
  }
};

// @desc  Adjust batch stock (add/remove)
// @route POST /api/batches/:id/adjust-stock
// @access Private
const adjustStock = async (req, res) => {
  try {
    const { type, quantity, reason } = req.body;
    const batch = await Batch.findById(req.params.id);
    if (!batch) return res.status(404).json({ success: false, message: 'Batch not found' });

    const qty = parseInt(quantity);
    if (qty <= 0) return res.status(400).json({ success: false, message: 'Quantity must be positive' });

    const prevQty = batch.quantity;
    let newQty;

    if (type === 'add') {
      newQty = prevQty + qty;
    } else if (type === 'remove') {
      if (qty > prevQty) {
        return res.status(400).json({ success: false, message: 'Insufficient stock' });
      }
      newQty = prevQty - qty;
    } else {
      return res.status(400).json({ success: false, message: 'Invalid type. Use "add" or "remove"' });
    }

    batch.quantity = newQty;
    await batch.save();

    await StockTransaction.create({
      medicine: batch.medicine,
      batch: batch._id,
      admin: req.admin._id,
      transactionType: type === 'add' ? 'STOCK_ADDED' : 'STOCK_REMOVED',
      quantity: qty,
      previousQuantity: prevQty,
      newQuantity: newQty,
      reason: reason || (type === 'add' ? 'Stock added' : 'Stock removed')
    });

    await updateMedicineTotalQty(batch.medicine);

    res.status(200).json({ success: true, message: `Stock ${type === 'add' ? 'added' : 'removed'} successfully`, newQuantity: newQty });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error adjusting stock' });
  }
};

// @desc  Delete batch
// @route DELETE /api/batches/:id
// @access Private
const deleteBatch = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.id);
    if (!batch) return res.status(404).json({ success: false, message: 'Batch not found' });

    await Batch.findByIdAndUpdate(req.params.id, { isActive: false });
    await updateMedicineTotalQty(batch.medicine);

    res.status(200).json({ success: true, message: 'Batch deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting batch' });
  }
};

module.exports = { getBatches, createBatch, updateBatch, adjustStock, deleteBatch };
