const Medicine = require('../models/Medicine');
const Batch = require('../models/Batch');
const StockTransaction = require('../models/StockTransaction');
const { getExpiryStatus, getStockStatus } = require('../utils/expiryHelper');

// @desc  Get dashboard summary
// @route GET /api/dashboard
// @access Private
const getDashboard = async (req, res) => {
  try {
    const medicines = await Medicine.find({ isActive: true });
    const batches = await Batch.find({ isActive: true })
      .populate('medicine', 'name genericName category minimumStock unit')
      .populate('supplier', 'name');

    // Compute totals
    let totalStock = 0;
    let lowStockMeds = new Set();
    let outOfStockMeds = new Set();
    let expiredBatches = 0;
    let expiringSoonBatches = 0;
    let expiringBatches = 0;
    let safeBatches = 0;

    const medicineStockMap = {};

    batches.forEach(b => {
      totalStock += b.quantity;

      const { status } = getExpiryStatus(b.expiryDate);
      if (status === 'EXPIRED') expiredBatches++;
      else if (status === 'EXPIRING_SOON') expiringSoonBatches++;
      else if (status === 'EXPIRING') expiringBatches++;
      else safeBatches++;

      // Accumulate per medicine stock
      const medId = b.medicine?._id?.toString();
      if (medId) {
        if (!medicineStockMap[medId]) {
          medicineStockMap[medId] = { qty: 0, minStock: b.medicine?.minimumStock || 10, medicine: b.medicine };
        }
        medicineStockMap[medId].qty += b.quantity;
      }
    });

    // Determine low/out-of-stock
    Object.values(medicineStockMap).forEach(({ qty, minStock, medicine }) => {
      const medId = medicine?._id?.toString();
      const status = getStockStatus(qty, minStock);
      if (status === 'OUT_OF_STOCK') outOfStockMeds.add(medId);
      else if (status === 'LOW_STOCK') lowStockMeds.add(medId);
    });

    // Low stock details
    const lowStockDetails = await Promise.all(
      [...lowStockMeds, ...outOfStockMeds].map(async (medId) => {
        const info = medicineStockMap[medId];
        if (!info) return null;
        const batchList = batches.filter(b => b.medicine?._id?.toString() === medId);
        const supplier = batchList[0]?.supplier;
        return {
          medicine: info.medicine,
          totalQuantity: info.qty,
          minimumStock: info.minStock,
          stockStatus: getStockStatus(info.qty, info.minStock),
          supplier,
          batch: batchList[0]
        };
      })
    );

    // Recently added medicines (last 7 days)
    const recentMedicines = await Medicine.find({ isActive: true })
      .sort({ createdAt: -1 })
      .limit(5);

    // Recent transactions
    const recentTransactions = await StockTransaction.find()
      .populate('medicine', 'name')
      .populate('batch', 'batchNumber')
      .populate('admin', 'name')
      .sort({ createdAt: -1 })
      .limit(10);

    // Category distribution
    const categoryDist = {};
    medicines.forEach(m => {
      categoryDist[m.category] = (categoryDist[m.category] || 0) + 1;
    });

    // Expiry status chart data
    const expiryChartData = [
      { name: 'Expired', value: expiredBatches, color: '#ef4444' },
      { name: 'Expiring Soon', value: expiringSoonBatches, color: '#f97316' },
      { name: 'Expiring (30d)', value: expiringBatches, color: '#eab308' },
      { name: 'Safe', value: safeBatches, color: '#22c55e' }
    ];

    // Stock overview chart data (top 8 medicines by qty)
    const stockChartData = Object.entries(medicineStockMap)
      .map(([id, { qty, medicine }]) => ({
        name: medicine?.name || 'Unknown',
        quantity: qty,
        minStock: medicine?.minimumStock || 10
      }))
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 8);

    res.status(200).json({
      success: true,
      data: {
        summary: {
          totalMedicines: medicines.length,
          totalStock,
          lowStock: lowStockMeds.size,
          expiringSoon: expiringSoonBatches,
          expired: expiredBatches,
          outOfStock: outOfStockMeds.size
        },
        expiryOverview: {
          expired: expiredBatches,
          expiringSoon: expiringSoonBatches,
          expiring: expiringBatches,
          safe: safeBatches
        },
        lowStockMedicines: lowStockDetails.filter(Boolean).slice(0, 10),
        recentMedicines,
        recentTransactions,
        charts: {
          categoryDistribution: Object.entries(categoryDist).map(([name, value]) => ({ name, value })),
          expiryStatus: expiryChartData,
          stockOverview: stockChartData
        }
      }
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ success: false, message: 'Error fetching dashboard data' });
  }
};

module.exports = { getDashboard };
