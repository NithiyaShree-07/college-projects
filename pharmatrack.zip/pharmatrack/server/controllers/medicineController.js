const Medicine = require('../models/Medicine');
const Batch = require('../models/Batch');
const StockTransaction = require('../models/StockTransaction');
const { getExpiryStatus, getStockStatus } = require('../utils/expiryHelper');

// Helper: update medicine totalQuantity
const updateMedicineTotalQty = async (medicineId) => {
  const batches = await Batch.find({ medicine: medicineId, isActive: true });
  const total = batches.reduce((sum, b) => sum + b.quantity, 0);
  await Medicine.findByIdAndUpdate(medicineId, { totalQuantity: total });
  return total;
};

// @desc  Get all medicines with filters, search, pagination
// @route GET /api/medicines
// @access Private
const getMedicines = async (req, res) => {
  try {
    const {
      search, category, expiryStatus, stockStatus, supplier,
      page = 1, limit = 10, sortBy = 'name', sortOrder = 'asc'
    } = req.query;

    let query = { isActive: true };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { genericName: { $regex: search, $options: 'i' } }
      ];
    }
    if (category) query.category = category;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

    let medicines = await Medicine.find(query).sort(sort).skip(skip).limit(parseInt(limit));

    // Enrich with batch data
    const enriched = await Promise.all(medicines.map(async (med) => {
      const medObj = med.toObject();
      const batches = await Batch.find({ medicine: med._id, isActive: true })
        .populate('supplier', 'name');

      const totalQty = batches.reduce((sum, b) => sum + b.quantity, 0);

      // Compute expiry across all batches
      let overallExpiryStatus = 'SAFE';
      let nearestExpiry = null;
      batches.forEach(b => {
        const { status, daysUntilExpiry } = getExpiryStatus(b.expiryDate);
        if (!nearestExpiry || daysUntilExpiry < nearestExpiry) {
          nearestExpiry = daysUntilExpiry;
          overallExpiryStatus = status;
        }
      });

      const stockStatus = getStockStatus(totalQty, med.minimumStock);
      const supplierNames = [...new Set(batches.map(b => b.supplier?.name).filter(Boolean))];

      // Filter by expiryStatus
      if (expiryStatus && overallExpiryStatus !== expiryStatus) return null;
      // Filter by stockStatus
      if (stockStatus && req.query.stockStatus && stockStatus !== req.query.stockStatus) return null;
      // Filter by supplier
      if (supplier && !supplierNames.includes(supplier)) return null;

      return {
        ...medObj,
        totalQuantity: totalQty,
        expiryStatus: overallExpiryStatus,
        daysUntilExpiry: nearestExpiry,
        stockStatus,
        suppliers: supplierNames,
        batchCount: batches.length,
        batches: batches.map(b => ({
          ...b.toObject(),
          expiryStatus: getExpiryStatus(b.expiryDate).status,
          daysUntilExpiry: getExpiryStatus(b.expiryDate).daysUntilExpiry
        }))
      };
    }));

    const filtered = enriched.filter(Boolean);
    const total = await Medicine.countDocuments(query);

    res.status(200).json({
      success: true,
      data: filtered,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('Get medicines error:', error);
    res.status(500).json({ success: false, message: 'Error fetching medicines' });
  }
};

// @desc  Get single medicine with all batches
// @route GET /api/medicines/:id
// @access Private
const getMedicine = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);
    if (!medicine || !medicine.isActive) {
      return res.status(404).json({ success: false, message: 'Medicine not found' });
    }

    const batches = await Batch.find({ medicine: medicine._id, isActive: true })
      .populate('supplier', 'name email phone contactPerson');

    const totalQty = batches.reduce((sum, b) => sum + b.quantity, 0);
    const transactions = await StockTransaction.find({ medicine: medicine._id })
      .populate('admin', 'name email')
      .populate('batch', 'batchNumber')
      .sort({ createdAt: -1 })
      .limit(20);

    const enrichedBatches = batches.map(b => ({
      ...b.toObject(),
      ...getExpiryStatus(b.expiryDate)
    }));

    res.status(200).json({
      success: true,
      data: {
        ...medicine.toObject(),
        totalQuantity: totalQty,
        stockStatus: getStockStatus(totalQty, medicine.minimumStock),
        batches: enrichedBatches,
        transactions
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching medicine' });
  }
};

// @desc  Create medicine + initial batch
// @route POST /api/medicines
// @access Private
const createMedicine = async (req, res) => {
  try {
    const {
      name, genericName, category, manufacturer, unit, minimumStock,
      storageLocation, notes,
      // Batch fields
      batchNumber, quantity, purchasePrice, sellingPrice,
      manufacturingDate, expiryDate, supplier
    } = req.body;

    // Validate expiry date
    if (new Date(expiryDate) <= new Date(manufacturingDate)) {
      return res.status(400).json({ success: false, message: 'Expiry date must be after manufacturing date' });
    }

    // Create medicine
    const medicine = await Medicine.create({
      name, genericName, category, manufacturer, unit,
      minimumStock: minimumStock || 10, storageLocation, notes
    });

    // Create initial batch
    const batch = await Batch.create({
      medicine: medicine._id,
      supplier,
      batchNumber,
      quantity: parseInt(quantity) || 0,
      purchasePrice: parseFloat(purchasePrice),
      sellingPrice: parseFloat(sellingPrice),
      manufacturingDate,
      expiryDate
    });

    // Log initial stock transaction
    if (parseInt(quantity) > 0) {
      await StockTransaction.create({
        medicine: medicine._id,
        batch: batch._id,
        admin: req.admin._id,
        transactionType: 'INITIAL',
        quantity: parseInt(quantity),
        previousQuantity: 0,
        newQuantity: parseInt(quantity),
        reason: 'Initial stock entry'
      });
    }

    // Update total
    await updateMedicineTotalQty(medicine._id);

    res.status(201).json({
      success: true,
      message: 'Medicine added successfully',
      data: medicine
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Batch number already exists for this medicine' });
    }
    console.error('Create medicine error:', error);
    res.status(500).json({ success: false, message: error.message || 'Error creating medicine' });
  }
};

// @desc  Update medicine
// @route PUT /api/medicines/:id
// @access Private
const updateMedicine = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);
    if (!medicine || !medicine.isActive) {
      return res.status(404).json({ success: false, message: 'Medicine not found' });
    }

    const updated = await Medicine.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({ success: true, message: 'Medicine updated successfully', data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating medicine' });
  }
};

// @desc  Soft delete medicine
// @route DELETE /api/medicines/:id
// @access Private
const deleteMedicine = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);
    if (!medicine || !medicine.isActive) {
      return res.status(404).json({ success: false, message: 'Medicine not found' });
    }

    await Medicine.findByIdAndUpdate(req.params.id, { isActive: false });
    await Batch.updateMany({ medicine: req.params.id }, { isActive: false });

    res.status(200).json({ success: true, message: 'Medicine deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting medicine' });
  }
};

module.exports = { getMedicines, getMedicine, createMedicine, updateMedicine, deleteMedicine, updateMedicineTotalQty };
