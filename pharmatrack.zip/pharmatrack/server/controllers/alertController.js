const Batch = require('../models/Batch');
const Medicine = require('../models/Medicine');
const { getExpiryStatus, getStockStatus } = require('../utils/expiryHelper');

// @desc  Get all alerts (expiry + low stock)
// @route GET /api/alerts
// @access Private
const getAlerts = async (req, res) => {
  try {
    const { type, search } = req.query;

    const batches = await Batch.find({ isActive: true })
      .populate('medicine', 'name genericName category minimumStock unit storageLocation')
      .populate('supplier', 'name phone');

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let expiryAlerts = [];
    let stockAlerts = [];

    batches.forEach(b => {
      const { status, daysUntilExpiry } = getExpiryStatus(b.expiryDate);
      const stockStatus = getStockStatus(b.quantity, b.medicine?.minimumStock || 10);

      const baseAlert = {
        _id: b._id,
        medicine: b.medicine,
        batch: { _id: b._id, batchNumber: b.batchNumber },
        supplier: b.supplier,
        quantity: b.quantity,
        expiryDate: b.expiryDate,
        daysUntilExpiry,
        isReviewed: false
      };

      if (status === 'EXPIRED' || status === 'EXPIRING_SOON' || status === 'EXPIRING') {
        expiryAlerts.push({ ...baseAlert, alertType: 'EXPIRY', expiryStatus: status });
      }

      if (stockStatus === 'LOW_STOCK' || stockStatus === 'OUT_OF_STOCK') {
        stockAlerts.push({ ...baseAlert, alertType: 'STOCK', stockStatus, minimumStock: b.medicine?.minimumStock });
      }
    });

    // Sort expiry alerts: expired first, then soonest
    expiryAlerts.sort((a, b) => a.daysUntilExpiry - b.daysUntilExpiry);

    let alerts = [...expiryAlerts, ...stockAlerts];

    // Filter by type
    if (type === 'expiry') alerts = expiryAlerts;
    if (type === 'stock') alerts = stockAlerts;
    if (type === 'expired') alerts = expiryAlerts.filter(a => a.expiryStatus === 'EXPIRED');
    if (type === 'expiring_soon') alerts = expiryAlerts.filter(a => a.expiryStatus === 'EXPIRING_SOON');
    if (type === 'expiring') alerts = expiryAlerts.filter(a => a.expiryStatus === 'EXPIRING');
    if (type === 'low_stock') alerts = stockAlerts.filter(a => a.stockStatus === 'LOW_STOCK');
    if (type === 'out_of_stock') alerts = stockAlerts.filter(a => a.stockStatus === 'OUT_OF_STOCK');

    // Search
    if (search) {
      const s = search.toLowerCase();
      alerts = alerts.filter(a =>
        a.medicine?.name?.toLowerCase().includes(s) ||
        a.batch?.batchNumber?.toLowerCase().includes(s) ||
        a.supplier?.name?.toLowerCase().includes(s)
      );
    }

    res.status(200).json({
      success: true,
      data: alerts,
      counts: {
        total: alerts.length,
        expired: expiryAlerts.filter(a => a.expiryStatus === 'EXPIRED').length,
        expiringSoon: expiryAlerts.filter(a => a.expiryStatus === 'EXPIRING_SOON').length,
        expiring: expiryAlerts.filter(a => a.expiryStatus === 'EXPIRING').length,
        lowStock: stockAlerts.filter(a => a.stockStatus === 'LOW_STOCK').length,
        outOfStock: stockAlerts.filter(a => a.stockStatus === 'OUT_OF_STOCK').length
      }
    });
  } catch (error) {
    console.error('Get alerts error:', error);
    res.status(500).json({ success: false, message: 'Error fetching alerts' });
  }
};

// @desc  Get alert count (for navbar bell)
// @route GET /api/alerts/count
// @access Private
const getAlertCount = async (req, res) => {
  try {
    const batches = await Batch.find({ isActive: true })
      .populate('medicine', 'minimumStock');

    let count = 0;
    batches.forEach(b => {
      const { status } = getExpiryStatus(b.expiryDate);
      const stockStatus = getStockStatus(b.quantity, b.medicine?.minimumStock || 10);
      if (status !== 'SAFE') count++;
      if (stockStatus !== 'IN_STOCK') count++;
    });

    res.status(200).json({ success: true, count });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching alert count' });
  }
};

module.exports = { getAlerts, getAlertCount };
