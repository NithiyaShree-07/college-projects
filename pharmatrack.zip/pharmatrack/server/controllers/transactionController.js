const StockTransaction = require('../models/StockTransaction');

// @desc  Get all stock transactions
// @route GET /api/transactions
// @access Private
const getTransactions = async (req, res) => {
  try {
    const { medicineId, type, page = 1, limit = 20 } = req.query;
    const query = {};
    if (medicineId) query.medicine = medicineId;
    if (type) query.transactionType = type;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await StockTransaction.countDocuments(query);

    const transactions = await StockTransaction.find(query)
      .populate('medicine', 'name genericName category')
      .populate('batch', 'batchNumber expiryDate')
      .populate('admin', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      data: transactions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching transactions' });
  }
};

module.exports = { getTransactions };
