const Supplier = require('../models/Supplier');
const Batch = require('../models/Batch');

// @desc  Get all suppliers
// @route GET /api/suppliers
// @access Private
const getSuppliers = async (req, res) => {
  try {
    const suppliers = await Supplier.find({ isActive: true }).sort({ name: 1 });

    const enriched = await Promise.all(suppliers.map(async (s) => {
      const batches = await Batch.find({ supplier: s._id, isActive: true })
        .populate('medicine', 'name category');
      const uniqueMedicines = [...new Set(batches.map(b => b.medicine?._id?.toString()))].length;
      return { ...s.toObject(), medicineCount: uniqueMedicines, batchCount: batches.length };
    }));

    res.status(200).json({ success: true, data: enriched });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching suppliers' });
  }
};

// @desc  Get single supplier
// @route GET /api/suppliers/:id
// @access Private
const getSupplier = async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier || !supplier.isActive) {
      return res.status(404).json({ success: false, message: 'Supplier not found' });
    }

    const batches = await Batch.find({ supplier: supplier._id, isActive: true })
      .populate('medicine', 'name genericName category unit');

    res.status(200).json({ success: true, data: { ...supplier.toObject(), batches } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching supplier' });
  }
};

// @desc  Create supplier
// @route POST /api/suppliers
// @access Private
const createSupplier = async (req, res) => {
  try {
    const { name, contactPerson, phone, email, address, gstin, notes } = req.body;

    const existing = await Supplier.findOne({ name: name.trim() });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Supplier with this name already exists' });
    }

    const supplier = await Supplier.create({ name, contactPerson, phone, email, address, gstin, notes });
    res.status(201).json({ success: true, message: 'Supplier created', data: supplier });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error creating supplier' });
  }
};

// @desc  Update supplier
// @route PUT /api/suppliers/:id
// @access Private
const updateSupplier = async (req, res) => {
  try {
    const supplier = await Supplier.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    if (!supplier) return res.status(404).json({ success: false, message: 'Supplier not found' });
    res.status(200).json({ success: true, message: 'Supplier updated', data: supplier });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating supplier' });
  }
};

// @desc  Delete supplier
// @route DELETE /api/suppliers/:id
// @access Private
const deleteSupplier = async (req, res) => {
  try {
    const batches = await Batch.countDocuments({ supplier: req.params.id, isActive: true });
    if (batches > 0) {
      return res.status(400).json({ success: false, message: 'Cannot delete supplier with active batches. Reassign first.' });
    }

    await Supplier.findByIdAndUpdate(req.params.id, { isActive: false });
    res.status(200).json({ success: true, message: 'Supplier deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting supplier' });
  }
};

module.exports = { getSuppliers, getSupplier, createSupplier, updateSupplier, deleteSupplier };
