const express = require('express');
const router = express.Router();
const { getBatches, createBatch, updateBatch, adjustStock, deleteBatch } = require('../controllers/batchController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/', getBatches);
router.post('/', createBatch);
router.put('/:id', updateBatch);
router.post('/:id/adjust-stock', adjustStock);
router.delete('/:id', deleteBatch);

module.exports = router;
