const express = require('express');
const router = express.Router();
const { getMedicines, getMedicine, createMedicine, updateMedicine, deleteMedicine } = require('../controllers/medicineController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/', getMedicines);
router.post('/', createMedicine);
router.get('/:id', getMedicine);
router.put('/:id', updateMedicine);
router.delete('/:id', deleteMedicine);

module.exports = router;
