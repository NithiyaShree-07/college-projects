const express = require('express');
const router = express.Router();
const { getAlerts, getAlertCount } = require('../controllers/alertController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/', getAlerts);
router.get('/count', getAlertCount);

module.exports = router;
