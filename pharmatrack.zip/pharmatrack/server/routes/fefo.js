const express = require('express');
const router = express.Router();
const { getFEFO } = require('../controllers/fefoController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/', getFEFO);

module.exports = router;
