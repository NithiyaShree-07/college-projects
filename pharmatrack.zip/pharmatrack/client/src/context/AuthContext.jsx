import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authService } from '../services';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadAdmin = useCallback(async () => {
    const token = localStorage.getItem('pharmatrack_token');
    if (!token) { setLoading(false); return; }
    try {
      const res = await authService.getMe();
      setAdmin(res.data.admin);
    } catch {
      localStorage.removeItem('pharmatrack_token');
      localStorage.removeItem('pharmatrack_admin');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAdmin(); }, [loadAdmin]);

  const login = (token, adminData) => {
    localStorage.setItem('pharmatrack_token', token);
    localStorage.setItem('pharmatrack_admin', JSON.stringify(adminData));
    setAdmin(adminData);
  };

  const logout = () => {
    localStorage.removeItem('pharmatrack_token');
    localStorage.removeItem('pharmatrack_admin');
    setAdmin(null);
  };

  return (
    <AuthContext.Provider value={{ admin, loading, login, logout, reload: loadAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
