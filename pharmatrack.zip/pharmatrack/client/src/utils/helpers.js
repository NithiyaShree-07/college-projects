// Expiry status helpers — mirrors server logic, always computed fresh
export const getExpiryStatus = (expiryDate) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDate);
  expiry.setHours(0, 0, 0, 0);
  const diffMs = expiry - today;
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return { status: 'EXPIRED', daysUntilExpiry: diffDays };
  if (diffDays <= 7) return { status: 'EXPIRING_SOON', daysUntilExpiry: diffDays };
  if (diffDays <= 30) return { status: 'EXPIRING', daysUntilExpiry: diffDays };
  return { status: 'SAFE', daysUntilExpiry: diffDays };
};

export const getStockStatus = (quantity, minimumStock) => {
  if (quantity === 0) return 'OUT_OF_STOCK';
  if (quantity <= minimumStock) return 'LOW_STOCK';
  return 'IN_STOCK';
};

export const formatDate = (date) => {
  if (!date) return '—';
  return new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const formatCurrency = (val) => {
  if (val == null) return '—';
  return `₹${parseFloat(val).toFixed(2)}`;
};

export const formatDateTime = (date) => {
  if (!date) return '—';
  return new Date(date).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
};

export const expiryBadgeClass = (status) => {
  switch (status) {
    case 'EXPIRED': return 'badge badge-expired';
    case 'EXPIRING_SOON': return 'badge badge-expiring-soon';
    case 'EXPIRING': return 'badge badge-expiring';
    case 'SAFE': return 'badge badge-safe';
    default: return 'badge';
  }
};

export const stockBadgeClass = (status) => {
  switch (status) {
    case 'OUT_OF_STOCK': return 'badge badge-out-of-stock';
    case 'LOW_STOCK': return 'badge badge-low-stock';
    case 'IN_STOCK': return 'badge badge-in-stock';
    default: return 'badge';
  }
};

export const expiryLabel = (status, days) => {
  if (status === 'EXPIRED') return `Expired ${Math.abs(days)}d ago`;
  if (status === 'EXPIRING_SOON') return `Expires in ${days}d`;
  if (status === 'EXPIRING') return `Expires in ${days}d`;
  return 'Safe';
};

export const CATEGORIES = [
  'Analgesic', 'Antibiotic', 'Antihistamine', 'Antacid', 'Antidiabetic',
  'Antihypertensive', 'Lipid Lowering', 'Antiasthmatic', 'NSAID', 'Vitamin',
  'ORS', 'Proton Pump Inhibitor', 'Antifungal', 'Antiviral', 'Steroid',
  'Cardiac', 'Neurological', 'Dermatological', 'Ophthalmic', 'ENT', 'Other'
];

export const UNITS = [
  'Tablets', 'Capsules', 'Syrup (ml)', 'Injection (ml)', 'Cream (g)',
  'Ointment (g)', 'Drops (ml)', 'Sachet', 'Inhaler', 'Patch',
  'Suppository', 'Powder (g)', 'Strips'
];
