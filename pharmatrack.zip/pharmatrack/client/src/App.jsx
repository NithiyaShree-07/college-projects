import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import AppLayout from './layouts/AppLayout';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import AddMedicine from './pages/AddMedicine';
import EditMedicine from './pages/EditMedicine';
import MedicineDetail from './pages/MedicineDetail';
import Batches from './pages/Batches';
import ExpiryAlerts from './pages/ExpiryAlerts';
import LowStock from './pages/LowStock';
import FEFO from './pages/FEFO';
import Suppliers from './pages/Suppliers';
import StockHistory from './pages/StockHistory';
import AdminProfile from './pages/AdminProfile';
import Unauthorized from './pages/Unauthorized';

const ProtectedRoute = ({ children }) => {
  const { admin, loading } = useAuth();
  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <div className="spinner" />
    </div>
  );
  if (!admin) return <Navigate to="/login" replace />;
  return children;
};

const PublicRoute = ({ children }) => {
  const { admin, loading } = useAuth();
  if (loading) return null;
  if (admin) return <Navigate to="/dashboard" replace />;
  return children;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
    <Route path="/unauthorized" element={<Unauthorized />} />
    <Route path="/" element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
      <Route index element={<Navigate to="/dashboard" replace />} />
      <Route path="dashboard" element={<Dashboard />} />
      <Route path="inventory" element={<Inventory />} />
      <Route path="inventory/add" element={<AddMedicine />} />
      <Route path="inventory/edit/:id" element={<EditMedicine />} />
      <Route path="inventory/:id" element={<MedicineDetail />} />
      <Route path="batches" element={<Batches />} />
      <Route path="alerts" element={<ExpiryAlerts />} />
      <Route path="low-stock" element={<LowStock />} />
      <Route path="fefo" element={<FEFO />} />
      <Route path="suppliers" element={<Suppliers />} />
      <Route path="stock-history" element={<StockHistory />} />
      <Route path="profile" element={<AdminProfile />} />
    </Route>
    <Route path="*" element={<Navigate to="/dashboard" replace />} />
  </Routes>
);

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
}
