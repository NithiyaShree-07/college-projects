import API from './api';

export const authService = {
  login: (data) => API.post('/auth/login', data),
  getMe: () => API.get('/auth/me'),
  updateProfile: (data) => API.put('/auth/me', data),
  changePassword: (data) => API.put('/auth/change-password', data),
};

export const dashboardService = {
  getDashboard: () => API.get('/dashboard'),
};

export const medicineService = {
  getAll: (params) => API.get('/medicines', { params }),
  getOne: (id) => API.get(`/medicines/${id}`),
  create: (data) => API.post('/medicines', data),
  update: (id, data) => API.put(`/medicines/${id}`, data),
  delete: (id) => API.delete(`/medicines/${id}`),
};

export const batchService = {
  getAll: (params) => API.get('/batches', { params }),
  create: (data) => API.post('/batches', data),
  update: (id, data) => API.put(`/batches/${id}`, data),
  adjustStock: (id, data) => API.post(`/batches/${id}/adjust-stock`, data),
  delete: (id) => API.delete(`/batches/${id}`),
};

export const supplierService = {
  getAll: () => API.get('/suppliers'),
  getOne: (id) => API.get(`/suppliers/${id}`),
  create: (data) => API.post('/suppliers', data),
  update: (id, data) => API.put(`/suppliers/${id}`, data),
  delete: (id) => API.delete(`/suppliers/${id}`),
};

export const alertService = {
  getAll: (params) => API.get('/alerts', { params }),
  getCount: () => API.get('/alerts/count'),
};

export const transactionService = {
  getAll: (params) => API.get('/transactions', { params }),
};

export const fefoService = {
  getAll: () => API.get('/fefo'),
};
