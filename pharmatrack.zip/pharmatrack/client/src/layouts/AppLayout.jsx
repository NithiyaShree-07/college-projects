import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState, useEffect } from 'react';
import { alertService } from '../services';
import {
  LayoutDashboard, Package, PlusCircle, Layers, AlertTriangle,
  TrendingDown, ArrowUpDown, Truck, History, User, LogOut,
  Bell, Menu, X, FlaskConical, ChevronRight
} from 'lucide-react';

const navItems = [
  { section: 'Main' },
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { section: 'Inventory' },
  { to: '/inventory', icon: Package, label: 'Inventory' },
  { to: '/inventory/add', icon: PlusCircle, label: 'Add Medicine' },
  { to: '/batches', icon: Layers, label: 'Batch Management' },
  { section: 'Alerts' },
  { to: '/alerts', icon: AlertTriangle, label: 'Expiry Alerts', alertKey: 'expiry' },
  { to: '/low-stock', icon: TrendingDown, label: 'Low Stock', alertKey: 'stock' },
  { to: '/fefo', icon: ArrowUpDown, label: 'FEFO' },
  { section: 'Management' },
  { to: '/suppliers', icon: Truck, label: 'Suppliers' },
  { to: '/stock-history', icon: History, label: 'Stock History' },
  { section: 'Account' },
  { to: '/profile', icon: User, label: 'Admin Profile' },
];

export default function AppLayout() {
  const { admin, logout } = useAuth();
  const navigate = useNavigate();
  const [alertCount, setAlertCount] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    alertService.getCount().then(res => setAlertCount(res.data.count)).catch(() => {});
    const interval = setInterval(() => {
      alertService.getCount().then(res => setAlertCount(res.data.count)).catch(() => {});
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initials = admin?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || 'A';

  return (
    <div className="app-layout">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 99 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`sidebar${sidebarOpen ? ' open' : ''}`}>
        <div className="sidebar-logo">
          <div className="logo-mark">
            <div className="logo-icon">💊</div>
            <div>
              <div className="logo-text">PharmaTrack</div>
              <div className="logo-sub">Inventory System</div>
            </div>
          </div>
        </div>

        <nav className="sidebar-nav">
          {navItems.map((item, idx) => {
            if (item.section) return (
              <div key={idx} className="nav-section-label">{item.section}</div>
            );
            const Icon = item.icon;
            const hasAlert = item.alertKey && alertCount > 0;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/inventory'}
                className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
                onClick={() => setSidebarOpen(false)}
              >
                <Icon className="nav-icon" size={18} />
                <span>{item.label}</span>
                {hasAlert && <span className="nav-badge">{alertCount > 99 ? '99+' : alertCount}</span>}
              </NavLink>
            );
          })}

          <button className="nav-item" style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', marginTop: 4 }} onClick={handleLogout}>
            <LogOut className="nav-icon" size={18} />
            <span>Logout</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-admin-info">
            <div className="admin-avatar">{initials}</div>
            <div>
              <div className="admin-name">{admin?.name || 'Admin'}</div>
              <div className="admin-role">{admin?.role || 'Pharmacist'}</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="main-content">
        {/* Topbar */}
        <header className="topbar">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <button
              className="topbar-btn"
              style={{ display: 'none' }}
              id="menu-toggle"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
            <div className="topbar-left">
              <div className="page-title">PharmaTrack</div>
              <div className="page-subtitle">Smart Pharmacy Inventory & Expiry Monitoring</div>
            </div>
          </div>
          <div className="topbar-right">
            <button className="topbar-btn" onClick={() => navigate('/alerts')} title="Alerts">
              <Bell size={18} />
              {alertCount > 0 && <span className="alert-count-badge">{alertCount > 99 ? '99+' : alertCount}</span>}
            </button>
            <button className="topbar-btn" onClick={() => navigate('/profile')} title="Profile">
              <User size={18} />
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="page-content fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
