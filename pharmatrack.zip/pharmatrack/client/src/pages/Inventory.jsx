import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Eye, Edit, Trash2, Package, ChevronLeft, ChevronRight, Filter, PlusCircle, MinusCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { medicineService, supplierService } from '../services';
import { formatDate, formatCurrency, expiryBadgeClass, stockBadgeClass, expiryLabel, CATEGORIES } from '../utils/helpers';
import StockAdjustModal from '../components/StockAdjustModal';
import ConfirmDialog from '../components/ConfirmDialog';

export default function Inventory() {
  const navigate = useNavigate();
  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, pages: 1 });
  const [filters, setFilters] = useState({ search: '', category: '', expiryStatus: '', stockStatus: '', supplier: '' });
  const [suppliers, setSuppliers] = useState([]);
  const [adjustModal, setAdjustModal] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const fetchMedicines = useCallback(async () => {
    setLoading(true);
    try {
      const params = { ...filters, page: pagination.page, limit: pagination.limit };
      // Remove empty filters
      Object.keys(params).forEach(k => !params[k] && delete params[k]);
      const res = await medicineService.getAll(params);
      setMedicines(res.data.data);
      setPagination(p => ({ ...p, ...res.data.pagination }));
    } catch {
      toast.error('Failed to load medicines');
    } finally {
      setLoading(false);
    }
  }, [filters, pagination.page, pagination.limit]);

  useEffect(() => { fetchMedicines(); }, [fetchMedicines]);
  useEffect(() => { supplierService.getAll().then(r => setSuppliers(r.data.data)).catch(() => {}); }, []);

  const handleDelete = async (id) => {
    try {
      await medicineService.delete(id);
      toast.success('Medicine deleted successfully');
      fetchMedicines();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
    setDeleteConfirm(null);
  };

  const handleFilterChange = (key, val) => {
    setFilters(f => ({ ...f, [key]: val }));
    setPagination(p => ({ ...p, page: 1 }));
  };

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <h2>Medicine Inventory</h2>
          <p>{pagination.total} medicines in total</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/inventory/add')}>
          <Plus size={16} /> Add Medicine
        </button>
      </div>

      {/* Search */}
      <div className="search-bar">
        <div className="search-input-wrap">
          <Search className="search-icon" size={16} />
          <input
            className="form-control"
            placeholder="Search by name, generic name..."
            value={filters.search}
            onChange={e => handleFilterChange('search', e.target.value)}
          />
        </div>
      </div>

      {/* Filters */}
      <div className="filters-row">
        <select className="filter-select" value={filters.category} onChange={e => handleFilterChange('category', e.target.value)}>
          <option value="">All Categories</option>
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <select className="filter-select" value={filters.expiryStatus} onChange={e => handleFilterChange('expiryStatus', e.target.value)}>
          <option value="">All Expiry</option>
          <option value="EXPIRED">Expired</option>
          <option value="EXPIRING_SOON">Expiring Soon (≤7d)</option>
          <option value="EXPIRING">Expiring (≤30d)</option>
          <option value="SAFE">Safe</option>
        </select>
        <select className="filter-select" value={filters.stockStatus} onChange={e => handleFilterChange('stockStatus', e.target.value)}>
          <option value="">All Stock</option>
          <option value="OUT_OF_STOCK">Out of Stock</option>
          <option value="LOW_STOCK">Low Stock</option>
          <option value="IN_STOCK">In Stock</option>
        </select>
        <button className="btn btn-secondary btn-sm" onClick={() => { setFilters({ search: '', category: '', expiryStatus: '', stockStatus: '', supplier: '' }); }}>
          <Filter size={13} /> Clear
        </button>
      </div>

      <div className="card">
        {loading ? (
          <div className="loading-overlay"><div className="spinner" /></div>
        ) : medicines.length === 0 ? (
          <div className="empty-state">
            <Package size={48} />
            <h3>No medicines found</h3>
            <p>Try adjusting your filters or add a new medicine.</p>
            <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => navigate('/inventory/add')}>
              <Plus size={16} /> Add Medicine
            </button>
          </div>
        ) : (
          <>
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Medicine</th>
                    <th>Category</th>
                    <th>Batch(es)</th>
                    <th>Total Qty</th>
                    <th>Selling Price</th>
                    <th>Expiry Status</th>
                    <th>Stock Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {medicines.map(med => (
                    <tr key={med._id}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{med.name}</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>{med.genericName}</div>
                        <div style={{ fontSize: 11, color: '#94a3b8' }}>{med.manufacturer}</div>
                      </td>
                      <td><span className="badge" style={{ background: '#e0f2fe', color: '#0369a1' }}>{med.category}</span></td>
                      <td>{med.batchCount || med.batches?.length || '—'}</td>
                      <td style={{ fontWeight: 700 }}>{med.totalQuantity ?? 0} <small style={{ fontWeight: 400, color: '#64748b' }}>{med.unit}</small></td>
                      <td>{med.batches?.[0] ? formatCurrency(med.batches[0].sellingPrice) : '—'}</td>
                      <td>
                        {med.expiryStatus ? (
                          <span className={expiryBadgeClass(med.expiryStatus)}>
                            {expiryLabel(med.expiryStatus, med.daysUntilExpiry)}
                          </span>
                        ) : '—'}
                      </td>
                      <td>
                        <span className={stockBadgeClass(med.stockStatus)}>
                          {med.stockStatus?.replace(/_/g, ' ') || '—'}
                        </span>
                      </td>
                      <td>
                        <div className="action-btns">
                          <button className="btn-icon" title="View" onClick={() => navigate(`/inventory/${med._id}`)}><Eye size={14} /></button>
                          <button className="btn-icon" title="Edit" onClick={() => navigate(`/inventory/edit/${med._id}`)}><Edit size={14} /></button>
                          <button className="btn-icon success" title="Add Stock" onClick={() => setAdjustModal({ batchId: med.batches?.[0]?._id, medicineName: med.name, type: 'add', batches: med.batches })}>
                            <PlusCircle size={14} />
                          </button>
                          <button className="btn-icon" title="Remove Stock" onClick={() => setAdjustModal({ batchId: med.batches?.[0]?._id, medicineName: med.name, type: 'remove', batches: med.batches })}>
                            <MinusCircle size={14} />
                          </button>
                          <button className="btn-icon danger" title="Delete" onClick={() => setDeleteConfirm(med._id)}><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="pagination">
              <div className="pagination-info">
                Showing {(pagination.page - 1) * pagination.limit + 1}–{Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total}
              </div>
              <div className="pagination-btns">
                <button className="page-btn" disabled={pagination.page <= 1} onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))}>
                  <ChevronLeft size={14} />
                </button>
                {Array.from({ length: Math.min(pagination.pages, 5) }, (_, i) => i + 1).map(p => (
                  <button key={p} className={`page-btn${pagination.page === p ? ' active' : ''}`} onClick={() => setPagination(pp => ({ ...pp, page: p }))}>
                    {p}
                  </button>
                ))}
                <button className="page-btn" disabled={pagination.page >= pagination.pages} onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))}>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {adjustModal && (
        <StockAdjustModal
          data={adjustModal}
          onClose={() => setAdjustModal(null)}
          onSuccess={() => { setAdjustModal(null); fetchMedicines(); }}
        />
      )}

      {deleteConfirm && (
        <ConfirmDialog
          title="Delete Medicine"
          message="Are you sure you want to delete this medicine? All its batches will also be deactivated. This action cannot be undone."
          onConfirm={() => handleDelete(deleteConfirm)}
          onCancel={() => setDeleteConfirm(null)}
          confirmText="Delete"
          danger
        />
      )}
    </div>
  );
}
