import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FlaskConical, Save, ArrowLeft, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { medicineService, supplierService } from '../services';
import { CATEGORIES, UNITS } from '../utils/helpers';

const today = () => new Date().toISOString().split('T')[0];

const initForm = {
  name: '', genericName: '', category: '', manufacturer: '', unit: 'Tablets',
  minimumStock: 10, storageLocation: 'General Storage', notes: '',
  batchNumber: '', quantity: '', purchasePrice: '', sellingPrice: '',
  supplier: '', manufacturingDate: '', expiryDate: ''
};

export default function AddMedicine() {
  const navigate = useNavigate();
  const [form, setForm] = useState(initForm);
  const [errors, setErrors] = useState({});
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supplierService.getAll().then(r => setSuppliers(r.data.data)).catch(() => toast.error('Failed to load suppliers'));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    setErrors(er => ({ ...er, [name]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Medicine name is required';
    if (!form.genericName.trim()) e.genericName = 'Generic name is required';
    if (!form.category) e.category = 'Category is required';
    if (!form.manufacturer.trim()) e.manufacturer = 'Manufacturer is required';
    if (!form.batchNumber.trim()) e.batchNumber = 'Batch number is required';
    if (!form.supplier) e.supplier = 'Supplier is required';
    if (form.quantity === '' || form.quantity < 0) e.quantity = 'Quantity must be 0 or more';
    if (!form.purchasePrice || form.purchasePrice < 0) e.purchasePrice = 'Purchase price must be 0 or more';
    if (!form.sellingPrice || form.sellingPrice < 0) e.sellingPrice = 'Selling price must be 0 or more';
    if (!form.manufacturingDate) e.manufacturingDate = 'Manufacturing date is required';
    if (!form.expiryDate) e.expiryDate = 'Expiry date is required';
    if (form.expiryDate && form.manufacturingDate && new Date(form.expiryDate) <= new Date(form.manufacturingDate)) {
      e.expiryDate = 'Expiry date must be after manufacturing date';
    }
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); toast.error('Please fix the errors below.'); return; }

    setLoading(true);
    try {
      await medicineService.create(form);
      toast.success('Medicine added successfully!');
      navigate('/inventory');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add medicine');
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ label, name, required, children }) => (
    <div className="form-group">
      <label className="form-label">{label}{required && <span className="required">*</span>}</label>
      {children}
      {errors[name] && <div className="form-error"><AlertCircle size={12} />{errors[name]}</div>}
    </div>
  );

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <h2>Add New Medicine</h2>
          <p>Fill in the details to add a medicine with its initial batch</p>
        </div>
        <button className="btn btn-secondary" onClick={() => navigate('/inventory')}>
          <ArrowLeft size={16} /> Back
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Medicine Info */}
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-header">
            <div className="card-title"><FlaskConical size={16} /> Medicine Information</div>
          </div>
          <div className="card-body">
            <div className="form-row">
              <Field label="Medicine Name" name="name" required>
                <input name="name" className={`form-control${errors.name ? ' error' : ''}`} placeholder="e.g. Crocin Advance" value={form.name} onChange={handleChange} />
              </Field>
              <Field label="Generic Name" name="genericName" required>
                <input name="genericName" className={`form-control${errors.genericName ? ' error' : ''}`} placeholder="e.g. Paracetamol 500mg" value={form.genericName} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Category" name="category" required>
                <select name="category" className={`form-control${errors.category ? ' error' : ''}`} value={form.category} onChange={handleChange}>
                  <option value="">Select category</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Manufacturer" name="manufacturer" required>
                <input name="manufacturer" className={`form-control${errors.manufacturer ? ' error' : ''}`} placeholder="e.g. Cipla Ltd" value={form.manufacturer} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Unit" name="unit">
                <select name="unit" className="form-control" value={form.unit} onChange={handleChange}>
                  {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </Field>
              <Field label="Minimum Stock Level" name="minimumStock" required>
                <input type="number" name="minimumStock" className="form-control" min="0" value={form.minimumStock} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Storage Location" name="storageLocation">
                <input name="storageLocation" className="form-control" placeholder="e.g. Rack A1, Refrigerator" value={form.storageLocation} onChange={handleChange} />
              </Field>
              <Field label="Notes" name="notes">
                <input name="notes" className="form-control" placeholder="Optional notes" value={form.notes} onChange={handleChange} />
              </Field>
            </div>
          </div>
        </div>

        {/* Batch Info */}
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-header">
            <div className="card-title">📦 Initial Batch Details</div>
          </div>
          <div className="card-body">
            <div className="form-row">
              <Field label="Batch Number" name="batchNumber" required>
                <input name="batchNumber" className={`form-control${errors.batchNumber ? ' error' : ''}`} placeholder="e.g. PCM-A101" value={form.batchNumber} onChange={handleChange} />
              </Field>
              <Field label="Supplier" name="supplier" required>
                <select name="supplier" className={`form-control${errors.supplier ? ' error' : ''}`} value={form.supplier} onChange={handleChange}>
                  <option value="">Select supplier</option>
                  {suppliers.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}
                </select>
              </Field>
            </div>
            <div className="form-row">
              <Field label="Quantity" name="quantity" required>
                <input type="number" name="quantity" className={`form-control${errors.quantity ? ' error' : ''}`} min="0" placeholder="0" value={form.quantity} onChange={handleChange} />
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <Field label="Purchase Price (₹)" name="purchasePrice" required>
                  <input type="number" name="purchasePrice" className={`form-control${errors.purchasePrice ? ' error' : ''}`} min="0" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={handleChange} />
                </Field>
                <Field label="Selling Price (₹)" name="sellingPrice" required>
                  <input type="number" name="sellingPrice" className={`form-control${errors.sellingPrice ? ' error' : ''}`} min="0" step="0.01" placeholder="0.00" value={form.sellingPrice} onChange={handleChange} />
                </Field>
              </div>
            </div>
            <div className="form-row">
              <Field label="Manufacturing Date" name="manufacturingDate" required>
                <input type="date" name="manufacturingDate" className={`form-control${errors.manufacturingDate ? ' error' : ''}`} max={today()} value={form.manufacturingDate} onChange={handleChange} />
              </Field>
              <Field label="Expiry Date" name="expiryDate" required>
                <input type="date" name="expiryDate" className={`form-control${errors.expiryDate ? ' error' : ''}`} value={form.expiryDate} onChange={handleChange} />
              </Field>
            </div>
            {form.expiryDate && new Date(form.expiryDate) < new Date() && (
              <div className="alert-banner expired">
                <AlertCircle size={16} /> This batch is already expired. It will be flagged as EXPIRED in the system.
              </div>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button type="button" className="btn btn-secondary" onClick={() => navigate('/inventory')}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Saving...</> : <><Save size={16} /> Add Medicine</>}
          </button>
        </div>
      </form>
    </div>
  );
}
