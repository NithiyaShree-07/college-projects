import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layers, Plus, Search, Edit, Trash2, PlusCircle, MinusCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { batchService, medicineService, supplierService } from '../services';
import { formatDate, formatCurrency, expiryBadgeClass, stockBadgeClass, expiryLabel, getExpiryStatus, getStockStatus, UNITS } from '../utils/helpers';
import StockAdjustModal from '../components/StockAdjustModal';
import ConfirmDialog from '../components/ConfirmDialog';

export default function Batches() {
  const [batches, setBatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [medicines, setMedicines] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [adjustModal, setAdjustModal] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const fetchBatches = useCallback(async () => {
    setLoading(true);
    try {
      const res = await batchService.getAll();
      setBatches(res.data.data);
    } catch { toast.error('Failed to load batches'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    fetchBatches();
    medicineService.getAll({ limit: 100 }).then(r => setMedicines(r.data.data)).catch(() => {});
    supplierService.getAll().then(r => setSuppliers(r.data.data)).catch(() => {});
  }, [fetchBatches]);

  const handleDelete = async (id) => {
    try {
      await batchService.delete(id);
      toast.success('Batch deleted');
      fetchBatches();
    } catch (err) { toast.error(err.response?.data?.message || 'Delete failed'); }
    setDeleteConfirm(null);
  };

  const filtered = batches.filter(b =>
    !search ||
    b.medicine?.name?.toLowerCase().includes(search.toLowerCase()) ||
    b.batchNumber?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fade-in">
      <div className="page-header">
        <div><h2>Batch Management</h2><p>{batches.length} active batches</p></div>
        <button className="btn btn-primary" onClick={() => setShowAddModal(true)}><Plus size={16} /> Add Batch</button>
      </div>

      <div className="search-bar">
        <div className="search-input-wrap">
          <Search className="search-icon" size={16} />
          <input className="form-control" placeholder="Search by medicine name or batch number..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="loading-overlay"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="empty-state"><Layers size={48} /><h3>No batches found</h3><p>Add a batch to get started.</p></div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Batch #</th>
                  <th>Qty</th>
                  <th>Purchase</th>
                  <th>Selling</th>
                  <th>Mfg Date</th>
                  <th>Expiry Date</th>
                  <th>Expiry Status</th>
                  <th>Stock</th>
                  <th>Supplier</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(b => {
                  const { status, daysUntilExpiry } = getExpiryStatus(b.expiryDate);
                  const sStatus = getStockStatus(b.quantity, b.medicine?.minimumStock || 10);
                  return (
                    <tr key={b._id}>
                      <td><strong>{b.medicine?.name}</strong><br /><small style={{ color: '#64748b' }}>{b.medicine?.genericName}</small></td>
                      <td><span style={{ fontFamily: 'monospace', background: '#f1f5f9', padding: '2px 6px', borderRadius: 4, fontSize: 12 }}>{b.batchNumber}</span></td>
                      <td style={{ fontWeight: 700 }}>{b.quantity} <small style={{ color: '#64748b' }}>{b.medicine?.unit}</small></td>
                      <td>{formatCurrency(b.purchasePrice)}</td>
                      <td>{formatCurrency(b.sellingPrice)}</td>
                      <td>{formatDate(b.manufacturingDate)}</td>
                      <td>{formatDate(b.expiryDate)}</td>
                      <td><span className={expiryBadgeClass(status)}>{expiryLabel(status, daysUntilExpiry)}</span></td>
                      <td><span className={stockBadgeClass(sStatus)}>{sStatus?.replace(/_/g, ' ')}</span></td>
                      <td>{b.supplier?.name || '—'}</td>
                      <td>
                        <div className="action-btns">
                          <button className="btn-icon success" title="Add Stock" onClick={() => setAdjustModal({ batchId: b._id, medicineName: b.medicine?.name, type: 'add', batches: [b] })}><PlusCircle size={14} /></button>
                          <button className="btn-icon" title="Remove Stock" onClick={() => setAdjustModal({ batchId: b._id, medicineName: b.medicine?.name, type: 'remove', batches: [b] })}><MinusCircle size={14} /></button>
                          <button className="btn-icon danger" title="Delete" onClick={() => setDeleteConfirm(b._id)}><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showAddModal && <AddBatchModal medicines={medicines} suppliers={suppliers} onClose={() => setShowAddModal(false)} onSuccess={() => { setShowAddModal(false); fetchBatches(); }} />}
      {adjustModal && <StockAdjustModal data={adjustModal} onClose={() => setAdjustModal(null)} onSuccess={() => { setAdjustModal(null); fetchBatches(); }} />}
      {deleteConfirm && <ConfirmDialog title="Delete Batch" message="Delete this batch? Stock transactions will remain for audit." onConfirm={() => handleDelete(deleteConfirm)} onCancel={() => setDeleteConfirm(null)} confirmText="Delete" danger />}
    </div>
  );
}

function AddBatchModal({ medicines, suppliers, onClose, onSuccess }) {
  const [form, setForm] = useState({ medicine: '', supplier: '', batchNumber: '', quantity: '', purchasePrice: '', sellingPrice: '', manufacturingDate: '', expiryDate: '' });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = e => { setForm(f => ({ ...f, [e.target.name]: e.target.value })); setErrors(er => ({ ...er, [e.target.name]: '' })); };

  const handleSubmit = async e => {
    e.preventDefault();
    const errs = {};
    if (!form.medicine) errs.medicine = 'Required';
    if (!form.supplier) errs.supplier = 'Required';
    if (!form.batchNumber) errs.batchNumber = 'Required';
    if (form.quantity === '') errs.quantity = 'Required';
    if (!form.manufacturingDate) errs.manufacturingDate = 'Required';
    if (!form.expiryDate) errs.expiryDate = 'Required';
    if (form.expiryDate && form.manufacturingDate && new Date(form.expiryDate) <= new Date(form.manufacturingDate)) errs.expiryDate = 'Must be after mfg date';
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLoading(true);
    try {
      await batchService.create(form);
      toast.success('Batch added!');
      onSuccess();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to add batch'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <div className="modal-title"><Layers size={18} /> Add New Batch</div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Medicine<span className="required">*</span></label>
                <select name="medicine" className={`form-control${errors.medicine ? ' error' : ''}`} value={form.medicine} onChange={handleChange}>
                  <option value="">Select medicine</option>
                  {medicines.map(m => <option key={m._id} value={m._id}>{m.name}</option>)}
                </select>
                {errors.medicine && <div className="form-error">{errors.medicine}</div>}
              </div>
              <div className="form-group">
                <label className="form-label">Supplier<span className="required">*</span></label>
                <select name="supplier" className={`form-control${errors.supplier ? ' error' : ''}`} value={form.supplier} onChange={handleChange}>
                  <option value="">Select supplier</option>
                  {suppliers.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}
                </select>
                {errors.supplier && <div className="form-error">{errors.supplier}</div>}
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Batch Number<span className="required">*</span></label>
                <input name="batchNumber" className={`form-control${errors.batchNumber ? ' error' : ''}`} value={form.batchNumber} onChange={handleChange} />
                {errors.batchNumber && <div className="form-error">{errors.batchNumber}</div>}
              </div>
              <div className="form-group">
                <label className="form-label">Quantity<span className="required">*</span></label>
                <input type="number" name="quantity" className={`form-control${errors.quantity ? ' error' : ''}`} min="0" value={form.quantity} onChange={handleChange} />
                {errors.quantity && <div className="form-error">{errors.quantity}</div>}
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Purchase Price (₹)</label>
                <input type="number" name="purchasePrice" className="form-control" min="0" step="0.01" value={form.purchasePrice} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="form-label">Selling Price (₹)</label>
                <input type="number" name="sellingPrice" className="form-control" min="0" step="0.01" value={form.sellingPrice} onChange={handleChange} />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Mfg Date<span className="required">*</span></label>
                <input type="date" name="manufacturingDate" className={`form-control${errors.manufacturingDate ? ' error' : ''}`} value={form.manufacturingDate} onChange={handleChange} />
                {errors.manufacturingDate && <div className="form-error">{errors.manufacturingDate}</div>}
              </div>
              <div className="form-group">
                <label className="form-label">Expiry Date<span className="required">*</span></label>
                <input type="date" name="expiryDate" className={`form-control${errors.expiryDate ? ' error' : ''}`} value={form.expiryDate} onChange={handleChange} />
                {errors.expiryDate && <div className="form-error">{errors.expiryDate}</div>}
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Adding...' : 'Add Batch'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
