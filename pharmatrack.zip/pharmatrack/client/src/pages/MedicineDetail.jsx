import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, Package, Layers, Clock, TrendingDown, AlertTriangle, Truck } from 'lucide-react';
import toast from 'react-hot-toast';
import { medicineService } from '../services';
import { formatDate, formatDateTime, formatCurrency, expiryBadgeClass, stockBadgeClass, expiryLabel, getExpiryStatus, getStockStatus } from '../utils/helpers';

export default function MedicineDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    medicineService.getOne(id)
      .then(res => setData(res.data.data))
      .catch(() => { toast.error('Medicine not found'); navigate('/inventory'); })
      .finally(() => setLoading(false));
  }, [id, navigate]);

  if (loading) return <div className="loading-overlay"><div className="spinner" /></div>;
  if (!data) return null;

  const { batches = [], transactions = [] } = data;
  const totalQty = batches.reduce((s, b) => s + b.quantity, 0);
  const stockStatus = getStockStatus(totalQty, data.minimumStock);

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <h2>{data.name}</h2>
          <p>{data.genericName} · {data.category} · {data.manufacturer}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-secondary" onClick={() => navigate('/inventory')}><ArrowLeft size={16} /> Back</button>
          <button className="btn btn-primary" onClick={() => navigate(`/inventory/edit/${id}`)}><Edit size={16} /> Edit</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Medicine Info */}
        <div className="card">
          <div className="card-header"><div className="card-title"><Package size={16} /> Medicine Info</div></div>
          <div className="card-body">
            <div className="detail-grid">
              <div className="detail-item"><span className="detail-label">Name</span><span className="detail-value">{data.name}</span></div>
              <div className="detail-item"><span className="detail-label">Generic Name</span><span className="detail-value">{data.genericName}</span></div>
              <div className="detail-item"><span className="detail-label">Category</span><span className="detail-value">{data.category}</span></div>
              <div className="detail-item"><span className="detail-label">Manufacturer</span><span className="detail-value">{data.manufacturer}</span></div>
              <div className="detail-item"><span className="detail-label">Unit</span><span className="detail-value">{data.unit}</span></div>
              <div className="detail-item"><span className="detail-label">Min Stock</span><span className="detail-value">{data.minimumStock}</span></div>
              <div className="detail-item"><span className="detail-label">Storage</span><span className="detail-value">{data.storageLocation}</span></div>
              <div className="detail-item"><span className="detail-label">Added On</span><span className="detail-value">{formatDate(data.createdAt)}</span></div>
            </div>
            {data.notes && <div style={{ marginTop: 12, padding: 10, background: '#f8fafc', borderRadius: 8, fontSize: 13, color: '#64748b' }}>{data.notes}</div>}
          </div>
        </div>

        {/* Stock Summary */}
        <div className="card">
          <div className="card-header"><div className="card-title"><TrendingDown size={16} /> Stock Summary</div></div>
          <div className="card-body">
            <div style={{ textAlign: 'center', padding: '12px 0', marginBottom: 16 }}>
              <div style={{ fontSize: 52, fontWeight: 800, color: totalQty === 0 ? '#dc2626' : totalQty <= data.minimumStock ? '#d97706' : '#15803d' }}>{totalQty}</div>
              <div style={{ fontSize: 13, color: '#64748b' }}>{data.unit} in stock across {batches.length} batch(es)</div>
              <span className={stockBadgeClass(stockStatus)} style={{ marginTop: 8, display: 'inline-block' }}>{stockStatus?.replace(/_/g, ' ')}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 16px', background: '#f8fafc', borderRadius: 8, fontSize: 13 }}>
              <span>Minimum Stock:</span>
              <strong>{data.minimumStock} {data.unit}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Batches */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-header">
          <div className="card-title"><Layers size={16} /> Batches ({batches.length})</div>
        </div>
        {batches.length === 0 ? (
          <div className="empty-state" style={{ padding: 40 }}>No active batches</div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Batch #</th>
                  <th>Qty</th>
                  <th>Purchase</th>
                  <th>Selling</th>
                  <th>Mfg Date</th>
                  <th>Expiry Date</th>
                  <th>Expiry Status</th>
                  <th>Supplier</th>
                </tr>
              </thead>
              <tbody>
                {batches.sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate)).map(b => {
                  const { status, daysUntilExpiry } = getExpiryStatus(b.expiryDate);
                  return (
                    <tr key={b._id}>
                      <td><strong>{b.batchNumber}</strong></td>
                      <td style={{ fontWeight: 700 }}>{b.quantity}</td>
                      <td>{formatCurrency(b.purchasePrice)}</td>
                      <td>{formatCurrency(b.sellingPrice)}</td>
                      <td>{formatDate(b.manufacturingDate)}</td>
                      <td>{formatDate(b.expiryDate)}</td>
                      <td><span className={expiryBadgeClass(status)}>{expiryLabel(status, daysUntilExpiry)}</span></td>
                      <td>{b.supplier?.name || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Stock History */}
      <div className="card">
        <div className="card-header"><div className="card-title"><Clock size={16} /> Stock History (Recent 20)</div></div>
        {transactions.length === 0 ? (
          <div className="empty-state" style={{ padding: 40 }}>No transactions yet</div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Batch</th>
                  <th>Qty Changed</th>
                  <th>Before</th>
                  <th>After</th>
                  <th>Reason</th>
                  <th>By</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map(t => (
                  <tr key={t._id}>
                    <td style={{ fontSize: 12 }}>{formatDateTime(t.createdAt)}</td>
                    <td>
                      <span className={`badge ${t.transactionType === 'STOCK_ADDED' || t.transactionType === 'INITIAL' ? 'badge-added' : t.transactionType === 'STOCK_REMOVED' ? 'badge-removed' : 'badge-adjusted'}`}>
                        {t.transactionType?.replace('_', ' ')}
                      </span>
                    </td>
                    <td>{t.batch?.batchNumber}</td>
                    <td style={{ fontWeight: 700, color: t.transactionType === 'STOCK_REMOVED' ? '#dc2626' : '#15803d' }}>
                      {t.transactionType === 'STOCK_REMOVED' ? `-${t.quantity}` : `+${t.quantity}`}
                    </td>
                    <td>{t.previousQuantity}</td>
                    <td>{t.newQuantity}</td>
                    <td style={{ fontSize: 12, color: '#64748b' }}>{t.reason || '—'}</td>
                    <td style={{ fontSize: 12 }}>{t.admin?.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
