import { useState, useEffect } from 'react';
import { Search, AlertTriangle, Clock, Filter } from 'lucide-react';
import toast from 'react-hot-toast';
import { alertService } from '../services';
import { formatDate, expiryBadgeClass, stockBadgeClass, expiryLabel } from '../utils/helpers';

const TAB_TYPES = [
  { key: '', label: 'All Alerts' },
  { key: 'expired', label: '🔴 Expired' },
  { key: 'expiring_soon', label: '🟠 Expiring ≤7d' },
  { key: 'expiring', label: '🟡 Expiring ≤30d' },
  { key: 'low_stock', label: '⚠️ Low Stock' },
  { key: 'out_of_stock', label: '🚫 Out of Stock' },
];

export default function ExpiryAlerts() {
  const [alerts, setAlerts] = useState([]);
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    setLoading(true);
    alertService.getAll({ type: activeTab, search })
      .then(res => { setAlerts(res.data.data); setCounts(res.data.counts); })
      .catch(() => toast.error('Failed to load alerts'))
      .finally(() => setLoading(false));
  }, [activeTab, search]);

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <h2>Expiry & Stock Alerts</h2>
          <p>Automatically calculated from current date — no manual updates needed</p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <span className="badge badge-expired">{counts.expired || 0} Expired</span>
          <span className="badge badge-expiring-soon">{counts.expiringSoon || 0} Expiring Soon</span>
          <span className="badge badge-low-stock">{counts.lowStock || 0} Low Stock</span>
          <span className="badge badge-out-of-stock">{counts.outOfStock || 0} Out of Stock</span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 16 }}>
        {TAB_TYPES.map(t => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            style={{
              padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
              border: '1.5px solid', cursor: 'pointer', transition: 'all 0.2s',
              background: activeTab === t.key ? '#0ea5e9' : '#fff',
              color: activeTab === t.key ? '#fff' : '#64748b',
              borderColor: activeTab === t.key ? '#0ea5e9' : '#e2e8f0',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="search-bar">
        <div className="search-input-wrap">
          <Search className="search-icon" size={16} />
          <input className="form-control" placeholder="Search medicine, batch, supplier..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="loading-overlay"><div className="spinner" /></div>
        ) : alerts.length === 0 ? (
          <div className="empty-state">
            <AlertTriangle size={48} />
            <h3>No alerts found</h3>
            <p>All medicines are safe and well-stocked.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Medicine</th>
                  <th>Batch #</th>
                  <th>Quantity</th>
                  <th>Expiry Date</th>
                  <th>Days Remaining</th>
                  <th>Status</th>
                  <th>Supplier</th>
                </tr>
              </thead>
              <tbody>
                {alerts.map((alert, i) => (
                  <tr key={`${alert._id}-${i}`}>
                    <td>
                      <span className={`badge ${alert.alertType === 'EXPIRY' ? 'badge-expiring-soon' : 'badge-low-stock'}`} style={{ fontSize: 10 }}>
                        {alert.alertType === 'EXPIRY' ? '⏱ EXPIRY' : '📦 STOCK'}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{alert.medicine?.name}</div>
                      <div style={{ fontSize: 12, color: '#64748b' }}>{alert.medicine?.genericName}</div>
                    </td>
                    <td><span style={{ fontFamily: 'monospace', background: '#f1f5f9', padding: '2px 6px', borderRadius: 4, fontSize: 12 }}>{alert.batch?.batchNumber}</span></td>
                    <td style={{ fontWeight: 700 }}>{alert.quantity}</td>
                    <td>{formatDate(alert.expiryDate)}</td>
                    <td>
                      {alert.alertType === 'EXPIRY' ? (
                        <span style={{ fontWeight: 700, color: alert.daysUntilExpiry < 0 ? '#dc2626' : alert.daysUntilExpiry <= 7 ? '#ea580c' : '#d97706' }}>
                          {alert.daysUntilExpiry < 0 ? `${Math.abs(alert.daysUntilExpiry)}d ago` : `${alert.daysUntilExpiry}d left`}
                        </span>
                      ) : '—'}
                    </td>
                    <td>
                      {alert.alertType === 'EXPIRY' ? (
                        <span className={expiryBadgeClass(alert.expiryStatus)}>{alert.expiryStatus?.replace('_', ' ')}</span>
                      ) : (
                        <span className={stockBadgeClass(alert.stockStatus)}>{alert.stockStatus?.replace(/_/g, ' ')}</span>
                      )}
                    </td>
                    <td>{alert.supplier?.name || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
