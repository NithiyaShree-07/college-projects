import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, ArrowLeft, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { medicineService } from '../services';
import { CATEGORIES, UNITS } from '../utils/helpers';

export default function EditMedicine() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    medicineService.getOne(id).then(res => {
      const m = res.data.data;
      setForm({
        name: m.name, genericName: m.genericName, category: m.category,
        manufacturer: m.manufacturer, unit: m.unit,
        minimumStock: m.minimumStock, storageLocation: m.storageLocation || '',
        notes: m.notes || ''
      });
    }).catch(() => { toast.error('Medicine not found'); navigate('/inventory'); });
  }, [id, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    setErrors(er => ({ ...er, [name]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.name?.trim()) e.name = 'Required';
    if (!form.genericName?.trim()) e.genericName = 'Required';
    if (!form.category) e.category = 'Required';
    if (!form.manufacturer?.trim()) e.manufacturer = 'Required';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLoading(true);
    try {
      await medicineService.update(id, form);
      toast.success('Medicine updated!');
      navigate(`/inventory/${id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setLoading(false);
    }
  };

  if (!form) return <div className="loading-overlay"><div className="spinner" /></div>;

  const Field = ({ label, name, required, children }) => (
    <div className="form-group">
      <label className="form-label">{label}{required && <span className="required">*</span>}</label>
      {children}
      {errors[name] && <div className="form-error"><AlertCircle size={12} />{errors[name]}</div>}
    </div>
  );

  return (
    <div className="fade-in">
      <div className="page-header">
        <div><h2>Edit Medicine</h2><p>Update medicine information</p></div>
        <button className="btn btn-secondary" onClick={() => navigate(-1)}><ArrowLeft size={16} /> Back</button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-header"><div className="card-title">Medicine Details</div></div>
          <div className="card-body">
            <div className="form-row">
              <Field label="Medicine Name" name="name" required>
                <input name="name" className={`form-control${errors.name ? ' error' : ''}`} value={form.name} onChange={handleChange} />
              </Field>
              <Field label="Generic Name" name="genericName" required>
                <input name="genericName" className={`form-control${errors.genericName ? ' error' : ''}`} value={form.genericName} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Category" name="category" required>
                <select name="category" className={`form-control${errors.category ? ' error' : ''}`} value={form.category} onChange={handleChange}>
                  <option value="">Select</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Manufacturer" name="manufacturer" required>
                <input name="manufacturer" className={`form-control${errors.manufacturer ? ' error' : ''}`} value={form.manufacturer} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Unit" name="unit">
                <select name="unit" className="form-control" value={form.unit} onChange={handleChange}>
                  {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </Field>
              <Field label="Minimum Stock Level" name="minimumStock" required>
                <input type="number" name="minimumStock" className="form-control" min="0" value={form.minimumStock} onChange={handleChange} />
              </Field>
            </div>
            <div className="form-row">
              <Field label="Storage Location" name="storageLocation">
                <input name="storageLocation" className="form-control" value={form.storageLocation} onChange={handleChange} />
              </Field>
              <Field label="Notes" name="notes">
                <input name="notes" className="form-control" value={form.notes} onChange={handleChange} />
              </Field>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button type="button" className="btn btn-secondary" onClick={() => navigate(-1)}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Saving...</> : <><Save size={16} /> Save Changes</>}
          </button>
        </div>
      </form>
    </div>
  );
}
