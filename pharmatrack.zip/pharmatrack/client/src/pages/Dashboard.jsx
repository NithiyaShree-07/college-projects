import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Package, TrendingDown, AlertTriangle, Clock, XCircle, Boxes,
  ArrowRight, Activity
} from 'lucide-react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line
} from 'recharts';
import toast from 'react-hot-toast';
import { dashboardService } from '../services';
import { formatDate, formatDateTime, expiryBadgeClass, stockBadgeClass, expiryLabel } from '../utils/helpers';

const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#0ea5e9', '#8b5cf6', '#ec4899', '#14b8a6'];

const SummaryCard = ({ icon: Icon, label, value, color, onClick }) => (
  <div className={`summary-card ${color}`} onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
    <div className="summary-card-top">
      <div className={`summary-icon ${color}`}><Icon size={20} /></div>
    </div>
    <div>
      <div className="summary-value">{value ?? '—'}</div>
      <div className="summary-label">{label}</div>
    </div>
  </div>
);

export default function Dashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardService.getDashboard()
      .then(res => setData(res.data.data))
      .catch(() => toast.error('Failed to load dashboard data'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading-overlay"><div className="spinner" /></div>;

  if (!data) return (
    <div className="empty-state">
      <AlertTriangle size={48} />
      <h3>Failed to load dashboard</h3>
      <p>Please check your connection and refresh.</p>
    </div>
  );

  const { summary, expiryOverview, lowStockMedicines, recentMedicines, recentTransactions, charts } = data;

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <h2>Dashboard Overview</h2>
          <p>Real-time pharmacy inventory at a glance</p>
        </div>
        <div className="demo-banner" style={{ fontSize: 11, padding: '6px 14px' }}>
          🔬 Demo Inventory — For educational/testing purposes only
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <SummaryCard icon={Package} label="Total Medicines" value={summary.totalMedicines} color="blue" onClick={() => navigate('/inventory')} />
        <SummaryCard icon={Boxes} label="Total Stock" value={summary.totalStock?.toLocaleString()} color="green" />
        <SummaryCard icon={TrendingDown} label="Low Stock" value={summary.lowStock} color="yellow" onClick={() => navigate('/low-stock')} />
        <SummaryCard icon={Clock} label="Expiring Soon" value={summary.expiringSoon} color="orange" onClick={() => navigate('/alerts')} />
        <SummaryCard icon={AlertTriangle} label="Expired" value={summary.expired} color="red" onClick={() => navigate('/alerts')} />
        <SummaryCard icon={XCircle} label="Out of Stock" value={summary.outOfStock} color="purple" onClick={() => navigate('/low-stock')} />
      </div>

      {/* Expiry Overview */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-header">
          <div className="card-title"><Clock size={16} /> Expiry Overview</div>
        </div>
        <div className="card-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 16 }}>
          {[
            { label: 'Expired', value: expiryOverview.expired, cls: 'badge-expired' },
            { label: 'Expiring ≤7 days', value: expiryOverview.expiringSoon, cls: 'badge-expiring-soon' },
            { label: 'Expiring ≤30 days', value: expiryOverview.expiring, cls: 'badge-expiring' },
            { label: 'Safe', value: expiryOverview.safe, cls: 'badge-safe' },
          ].map(item => (
            <div key={item.label} style={{ textAlign: 'center', padding: '16px', borderRadius: 10, background: '#f8fafc', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: 28, fontWeight: 800, marginBottom: 6 }}>{item.value}</div>
              <span className={`badge ${item.cls}`}>{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="charts-grid">
        {/* Category Distribution */}
        <div className="card">
          <div className="card-header">
            <div className="card-title"><Activity size={16} /> Medicine Categories</div>
          </div>
          <div className="card-body">
            {charts.categoryDistribution?.length > 0 ? (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={charts.categoryDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                    {charts.categoryDistribution.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <div className="empty-state" style={{ padding: 40 }}>No data</div>}
          </div>
        </div>

        {/* Expiry Status Chart */}
        <div className="card">
          <div className="card-header">
            <div className="card-title"><AlertTriangle size={16} /> Expiry Status Distribution</div>
          </div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={charts.expiryStatus?.filter(d => d.value > 0)} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                  {charts.expiryStatus?.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stock Overview */}
        <div className="card" style={{ gridColumn: '1 / -1' }}>
          <div className="card-header">
            <div className="card-title"><Boxes size={16} /> Stock Level Overview (Top Medicines)</div>
          </div>
          <div className="card-body">
            {charts.stockOverview?.length > 0 ? (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={charts.stockOverview} margin={{ top: 5, right: 20, bottom: 40, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="quantity" name="Current Stock" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="minStock" name="Min Stock" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="empty-state" style={{ padding: 40 }}>No data</div>}
          </div>
        </div>
      </div>

      {/* Low Stock Medicines */}
      {lowStockMedicines?.length > 0 && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-header">
            <div className="card-title"><TrendingDown size={16} /> Low Stock Medicines</div>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/low-stock')}>
              View All <ArrowRight size={13} />
            </button>
          </div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Current Qty</th>
                  <th>Min Stock</th>
                  <th>Supplier</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {lowStockMedicines.slice(0, 5).map((item, i) => (
                  <tr key={i}>
                    <td><strong>{item.medicine?.name}</strong><br /><small style={{ color: '#64748b' }}>{item.medicine?.genericName}</small></td>
                    <td style={{ fontWeight: 700, color: item.totalQuantity === 0 ? '#dc2626' : '#d97706' }}>{item.totalQuantity}</td>
                    <td>{item.minimumStock}</td>
                    <td>{item.supplier?.name || '—'}</td>
                    <td><span className={stockBadgeClass(item.stockStatus)}>{item.stockStatus?.replace('_', ' ')}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Bottom grid: Recent Medicines + Recent Transactions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Recently Added Medicines */}
        <div className="card">
          <div className="card-header">
            <div className="card-title"><Package size={16} /> Recently Added</div>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/inventory')}>
              View All <ArrowRight size={13} />
            </button>
          </div>
          <div style={{ padding: '8px 0' }}>
            {recentMedicines?.length > 0 ? recentMedicines.map(m => (
              <div key={m._id} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 20px', borderBottom: '1px solid #f1f5f9'
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{m.name}</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>{m.category}</div>
                </div>
                <div style={{ fontSize: 12, color: '#94a3b8' }}>{formatDate(m.createdAt)}</div>
              </div>
            )) : <div className="empty-state" style={{ padding: 30 }}>No medicines yet</div>}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="card">
          <div className="card-header">
            <div className="card-title"><Activity size={16} /> Recent Transactions</div>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/stock-history')}>
              View All <ArrowRight size={13} />
            </button>
          </div>
          <div style={{ padding: '8px 0' }}>
            {recentTransactions?.length > 0 ? recentTransactions.map(t => (
              <div key={t._id} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 20px', borderBottom: '1px solid #f1f5f9'
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{t.medicine?.name}</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Batch: {t.batch?.batchNumber}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span className={`badge ${t.transactionType === 'STOCK_ADDED' || t.transactionType === 'INITIAL' ? 'badge-added' : t.transactionType === 'STOCK_REMOVED' ? 'badge-removed' : 'badge-adjusted'}`} style={{ fontSize: 10 }}>
                    {t.transactionType?.replace('_', ' ')}
                  </span>
                  <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>{formatDateTime(t.createdAt)}</div>
                </div>
              </div>
            )) : <div className="empty-state" style={{ padding: 30 }}>No transactions yet</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
